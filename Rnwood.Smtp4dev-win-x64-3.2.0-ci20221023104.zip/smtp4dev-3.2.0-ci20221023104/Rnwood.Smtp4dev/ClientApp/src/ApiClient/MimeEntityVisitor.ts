﻿

export default class MimeEntityVisitor {
 
    constructor() {
        
    }

    
}
