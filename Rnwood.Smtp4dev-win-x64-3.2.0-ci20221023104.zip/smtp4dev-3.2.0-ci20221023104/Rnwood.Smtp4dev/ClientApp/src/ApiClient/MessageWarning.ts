﻿

export default class MessageWarning {
 
    constructor(details: string, ) {
         
        this.details = details;
    }

     
    details: string;
}
