﻿

export default class MessageRelayOptions {
 
    constructor(overrideRecipientAddresses: string[], ) {
         
        this.overrideRecipientAddresses = overrideRecipientAddresses;
    }

     
    overrideRecipientAddresses: string[];
}
