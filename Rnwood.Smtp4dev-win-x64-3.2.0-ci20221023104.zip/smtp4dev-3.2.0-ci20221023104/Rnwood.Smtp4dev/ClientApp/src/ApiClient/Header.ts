﻿

export default class Header {
 
    constructor(name: string, value: string, ) {
         
        this.name = name; 
        this.value = value;
    }

     
    name: string; 
    value: string;
}
