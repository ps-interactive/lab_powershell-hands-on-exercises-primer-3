export default class Client {
    constructor(pageSize: number) {
        this.pageSize = pageSize;
    }

    pageSize: number;
}
