﻿import { AxiosRequestConfig } from "axios";

export default class MessageRequestConfig implements AxiosRequestConfig {
}