﻿namespace Rnwood.Smtp4dev.ApiModel
{
    public class Info
    {
        public string Version { get; set; }
        public string InfoVersion { get; set; }
    }
}