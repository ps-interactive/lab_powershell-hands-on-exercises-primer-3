﻿namespace Rnwood.Smtp4dev.ApiModel
{
    public class Client
    {
        public int PageSize { get; set; }
    }
}