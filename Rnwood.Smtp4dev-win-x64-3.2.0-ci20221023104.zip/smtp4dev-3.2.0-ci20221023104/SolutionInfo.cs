﻿using System.Reflection;

[assembly: AssemblyCompany("Robert N Wood")]
[assembly: AssemblyProduct("smtp4dev")]
[assembly: AssemblyCopyright("Copyright © Robert N Wood 2009-2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("3.0.100")]